  import java.awt.Color;

import javax.swing.JPanel;

public class MainPanel extends JPanel
{

    public static final int SCREEN_WIDTH = 1920;
    public static final int SCREEN_HEIGHT = 1080;

    private Leaderboard leaderboard;
    private GamePanel game;
    private Menu menu;
    
    public MainPanel()
    {
        setLayout(null);

        setBackground(Color.RED);

        leaderboard = new Leaderboard();

        /*
         * instantiate game and menu
         * set bounds to fill MainPanel
         * add to MainPanel
         * set invisible
         */

        game = new GamePanel(this, leaderboard);
        this.add(game);
        game.setBounds(0,0,MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        game.setVisible(false);

        menu = new Menu(this, leaderboard);
        this.add(menu);
        menu.setBounds(0,0,MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        menu.setVisible(false);

        
        //start on menu
        setMenuPanel();

    }


    //set other invisible and desired visible
    public void setGamePanel()
    {
        menu.setVisible(false);
        game.setVisible(true);
        game.requestFocus();
        game.startGameClock();
        game.startGame();
    }
    public void setMenuPanel()
    {
        game.setVisible(false);
        menu.setVisible(true);
        game.stopGameClock();
    }

    public Leaderboard getLeaderboard()
    {
        return leaderboard;
    }



}
