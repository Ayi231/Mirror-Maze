public class Goal extends PermanentSprite
{

    private GamePanel game;


    private final int[][] overworldXPos = 
    {
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L1
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L2
        {MainPanel.SCREEN_WIDTH, 1700}//L3
    };
    private final int[][] overworldYPos = 
    {
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L1
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L2
        {MainPanel.SCREEN_HEIGHT, 760}//L3
    };
    private final int[][] mirrorXPos = 
    {
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L1
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L2
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH}//L3
    };
    private final int[][] mirrorYPos = 
    {
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L1
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L2
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT}//L3
    };

    public Goal(GamePanel game)
    {
        super(game, "hostage.png", false, 0, 0, 0, 0, 0);
        this.game = game;

    }


    @Override
    public void setStage(int level, int stage, boolean overworld)
    {


        level--;
        stage--;
        //System.out.println(overworld);
        if(overworld)
        {
            setXPos(overworldXPos[level][stage]);
            setYPos(overworldYPos[level][stage]);
        }
        else //mirror world
        {
            setXPos(mirrorXPos[level][stage]);
            setYPos(mirrorYPos[level][stage]);
        }



    }


    public String toString()
    {
        return "Target";
    }




}
