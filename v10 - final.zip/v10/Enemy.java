import java.util.Random;

import javax.swing.ImageIcon;

public class Enemy extends Sprite
{
    
    Random rand = new Random();

    int spawnLocation;

    boolean facingRight;

    ImageIcon leftIcon, rightIcon;

    int target;
    final int TARGET_COOLDOWN = 50;
    int targetTimer;
    final int MOVE_RANGE_LEFT, MOVE_RANGE_RIGHT;

    int attackTimer, ATTACK_COOLDOWN;

    int health;

    final String name;


    public Enemy(GamePanel game, int xPos, int yPos)
    {
        super(game, "bossLeft.png", true, 0, 3.5, 1, xPos, yPos);

        MOVE_RANGE_LEFT = 1;
        MOVE_RANGE_RIGHT = 10;

        facingRight = false;
        rightIcon = new ImageIcon("images/sprites/bossRight.png");
        leftIcon = new ImageIcon("images/sprites/bossLeft.png");

        health = 15;
        game.getHUD().setBossHealth(health);

        name = "Boss";

        ATTACK_COOLDOWN = 80;
        attackTimer = ATTACK_COOLDOWN;


    }

    public Enemy(GamePanel game, int xPos, int yPos, int moveRangeLeft, int moveRangeRight)
    {
        super(game, "clownL.gif", true, 5, 3,2, xPos, yPos);
        
        MOVE_RANGE_LEFT = moveRangeLeft*Tile.SIZE;
        MOVE_RANGE_RIGHT = moveRangeRight*Tile.SIZE;

        facingRight = false;
        rightIcon = new ImageIcon("images/sprites/clownR.gif");
        leftIcon = new ImageIcon("images/sprites/clownL.gif");


        spawnLocation = xPos;

        health = 1;
        name = "Enemy";
        

    }


    public void tick()
    {
        super.tick();

        if(targetTimer > 0)
            targetTimer--;
        
        //     A-------B-------C
        //B: spawn loc
        //A: spawn - radius
        //C: spawn + radius
        //min = spawn - radius: min+0
        //max = min + (2*radius)
        
        if(targetTimer == 0 && rand.nextInt(20) == 0)
        {
            targetTimer = TARGET_COOLDOWN;
            target = spawnLocation-MOVE_RANGE_LEFT+rand.nextInt(MOVE_RANGE_LEFT+MOVE_RANGE_RIGHT+1);
            //System.out.println(target);

        }


        if(Math.abs(getXPos() - target) < 30)
        {
            stop();
        }
        else if(target > getXPos())
        {
            right();
        }
        else if(target < getXPos())
        {
            left();
        }

        
        
        
        
        
        /*if(r<50)        //0-49
        {
            stop();
            }
            else if(moveDirection == 0) //50-99 only matters if stopped 
            {
                if(r<75)    //50-74
                {
                    left();
                    }
                    else        //75-99
                    {
                        right();
                        }
                        }//*/
                        
                        
        if(name == "Enemy")
        {
            if(rand.nextInt(100)==0)
            {
                game.getSpriteManager().spawnProjectile(getXPos(), getYPos()+30, facingRight, this);
            }
        }
        else if(name == "Boss")
        {
            
            if(attackTimer > 0)
                attackTimer--;
            
            if(attackTimer == 0)
            {
                attackTimer = ATTACK_COOLDOWN;
                //int xAdj = -40;
                //int yAdj = 200;
                int xAdj = 70;
                int yAdj = 250;

                int rise = (this.getYPos()+yAdj) - (game.getSpriteManager().getPlayer().getYPos());
                int run = (this.getXPos()+xAdj) - (game.getSpriteManager().getPlayer().getXPos());

                game.getSpriteManager().spawnProjectile(getXPos()+xAdj, getYPos()+yAdj, -rise/(double)run, this);
            }



        }



        


    }


    private void left()
    {
        moveDirection = -1;
        facingRight = false;
        setIcon(leftIcon);
    }
    private void right()
    {
        moveDirection = 1;
        facingRight = true;
        setIcon(rightIcon);
    }
    private void stop()
    {
        moveDirection = 0;
    }


    public String toString()
    {
        return name;
    }
    
    public void kill()
    {
        health--;
        if(toString() == "Boss")
            game.getHUD().setBossHealth(health);
        if(health <= 0)
        {
            super.kill();
            if(toString() == "Boss")
                game.getHUD().setBossHealthVisible(false);
        }
    }


}
