public enum BlockTypes {
    AIR, WALL, BUTTON_LEFT, BUTTON_RIGHT, CAGE
}
// A, W, B, b, C