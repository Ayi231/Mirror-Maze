import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class HUD extends JPanel implements ActionListener
{
    private GamePanel game;
    private JLabel timer;
    private long timerMillis;
    private JProgressBar ammo, cooldown;

    private JLabel background;
    private JLabel levelDisplay;
    private JLabel namePrompt;
    private JTextField nameInput;

    private JPanel health;
    private JLabel h1, h2, h3;
    private ImageIcon fullHeart, emptyHeart;

    private JButton deathMsg;

    private JProgressBar bossHealth;

    
    public HUD(GamePanel game)
    {
        setLayout(null);
        this.game = game;
       
        setOpaque(false);

        timer = new JLabel("0:00.000s");
        timer.setBackground(Color.GREEN);
        timer.setForeground(Color.WHITE);
        timer.setOpaque(true);
        timer.setFont(new Font(Font.DIALOG_INPUT, Font.BOLD, 22));
        timer.setHorizontalAlignment(SwingConstants.CENTER);
        timer.setBorder(null);
        timer.setOpaque(false);
        add(timer);
        timer.setBounds(960, 0, 170, 50);


        health = new JPanel();
        health.setOpaque(false);
        health.setLayout(new GridLayout(1, 3));
        add(health);
        health.setBounds(640, 0, 300, 80);

        fullHeart = new ImageIcon("images/fullHeart.png");
        emptyHeart = new ImageIcon("images/emptyHeart.png");
        
        h1 = new JLabel(fullHeart);
        health.add(h1);
        h2 = new JLabel(fullHeart);
        health.add(h2);
        h3 = new JLabel(fullHeart);
        health.add(h3);


        ammo = new JProgressBar(SwingConstants.HORIZONTAL, 0, Player.MAX_AMMO);
        ammo.setOpaque(false);
        ammo.setForeground(Color.LIGHT_GRAY);
        ammo.setBorder(null);
        add(ammo);
        ammo.setBounds(960, 50, 280, 15);

        cooldown = new JProgressBar(SwingConstants.HORIZONTAL, 0, Player.ATTACK_COOLDOWN);
        cooldown.setOpaque(false);
        cooldown.setForeground(Color.MAGENTA);
        cooldown.setBorder(null);
        add(cooldown);
        cooldown.setBounds(960, 65, 280, 15);

        levelDisplay = new JLabel("Over World 1-1");
        levelDisplay.setBackground(Color.BLUE);
        levelDisplay.setForeground(Color.WHITE);
        levelDisplay.setFont(new Font(Font.DIALOG, Font.BOLD, 20));
        levelDisplay.setHorizontalAlignment(SwingConstants.CENTER);
        levelDisplay.setBorder(null);
        levelDisplay.setOpaque(false);
        add(levelDisplay);
        levelDisplay.setBounds(1140,0,200,50);


        nameInput = new JTextField(20);
        nameInput.setBackground(Color.DARK_GRAY);
        nameInput.setForeground(Color.WHITE);
        nameInput.setHorizontalAlignment(SwingConstants.HORIZONTAL);
        nameInput.setFont(new Font(Font.DIALOG_INPUT, Font.ITALIC, 18));
        add(nameInput);
        nameInput.setBounds(910, 300, 150, 50);
        nameInput.setVisible(false);
        nameInput.addActionListener(this);
        
        namePrompt = new JLabel("Input Name");
        namePrompt.setBackground(Color.DARK_GRAY);
        namePrompt.setForeground(Color.WHITE);
        namePrompt.setHorizontalAlignment(SwingConstants.HORIZONTAL);
        namePrompt.setFont(new Font(Font.DIALOG, Font.BOLD, 23));
        add(namePrompt);
        namePrompt.setBounds(910, 250, 150, 50);
        namePrompt.setVisible(false);


        deathMsg = new JButton("You Died");
        deathMsg.setBackground(Color.WHITE);
        deathMsg.setOpaque(false);
        deathMsg.setForeground(Color.RED);
        deathMsg.setBorder(null);
        deathMsg.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 80));
        add(deathMsg);
        deathMsg.setBounds(760, 225, 400, 150);
        deathMsg.setVisible(false);

        bossHealth = new JProgressBar(0, 10);
        bossHealth.setForeground(Color.RED);
        bossHealth.setOpaque(false);
        bossHealth.setBorder(null);
        add(bossHealth);
        bossHealth.setBounds(1000, 330, 200, 15);
        bossHealth.setVisible(false);

        background = new JLabel(new ImageIcon("images/hudBG.png"));
        background.setOpaque(false);
        add(background);
        background.setBounds(460,0,1000,80);


        repaint();

    }


    public void setHealthDisplay(int healthValue)
    {
        //health.setText(healthValue+"");
        switch (healthValue) {
            case 0:
                h1.setIcon(emptyHeart);
                h2.setIcon(emptyHeart);
                h3.setIcon(emptyHeart);
                break;
        
            case 1:
                h1.setIcon(fullHeart);
                h2.setIcon(emptyHeart);
                h3.setIcon(emptyHeart);
                break;
        
            case 2:
                h1.setIcon(fullHeart);
                h2.setIcon(fullHeart);
                h3.setIcon(emptyHeart);
                break;
        
            case 3:
                h1.setIcon(fullHeart);
                h2.setIcon(fullHeart);
                h3.setIcon(fullHeart);
                break;
        
            default:
                break;
        }
    }


    public void setStopwatch(long millis)
    {
        timerMillis = millis;
        
        long decimal = millis % 1000;

        long totalSeconds = (millis - decimal) / 1000;

        long seconds = totalSeconds % 60;

        long minutes = (totalSeconds - seconds) / 60; 
        

        timer.setText(minutes+":"+ (seconds<10?"0":"") +seconds+"."+decimal+"s");
        
    }


    public void setAmmo(int value)
    {
        ammo.setValue(value);
    }
    public void setCooldown(int value)
    {
        cooldown.setValue(value);
    }


    public void setDisplayLevel(int level, int stage, boolean over_world)
    {
        String title = "";
        if(over_world)
        {
            title+= "Overworld ";
        }
        else
        {
            title+= "Mirror World ";
        }
        title += level + "-" + stage;

        //System.out.println(title);

        levelDisplay.setText(title);
        
    }


    @Override
    public void actionPerformed(ActionEvent e)
    {
        nameInput.setVisible(false);
        namePrompt.setVisible(false);
        String name = nameInput.getText();
        if(name.length()>15)
            nameInput.getText().substring(0, 15);
        if(name.length()==0)
            name = "Player";
        game.getMainPanel().getLeaderboard().addPlacement(new Placement(name, timer.getText(), timerMillis));
        game.getMainPanel().setMenuPanel();
        nameInput.setText("");
    }


    public void promptNameInput()
    {
        namePrompt.setVisible(true);
        nameInput.setVisible(true);
        nameInput.requestFocus();
    }


    public void deathMsg(boolean visible)
    {
        deathMsg.setVisible(visible);
    }

    public void setBossHealthVisible(boolean visible)
    {
        bossHealth.setVisible(visible);
    }
    public void setBossHealth(int value)
    {
        bossHealth.setValue(value);
    }

}
