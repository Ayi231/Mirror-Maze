import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;


public class Menu extends JPanel implements MouseListener
{
    private MainPanel main;
    private Leaderboard leaderboard;

    private JLabel label;


    private JTextArea info;
    

    public Menu(MainPanel main, Leaderboard leaderboard)
    {
        addMouseListener(this);
        this.main = main;
        this.leaderboard = leaderboard;
        setLayout(null);
        


        info = new JTextArea(25, 35);
        try {info.read(new BufferedReader(new FileReader("info.txt")), null);} catch (Exception e){e.printStackTrace();}
        info.setOpaque(false);
        info.setEditable(false);
        info.setFont(leaderboard.getFont());
        info.setForeground(Color.WHITE);
        info.setFocusable(false);
        add(info);
        info.setBounds(MainPanel.SCREEN_WIDTH-leaderboard.totalWidth()-150, 0, leaderboard.totalWidth()+150, MainPanel.SCREEN_HEIGHT/2);
        repaint();




        add(leaderboard);
        this.leaderboard.setBounds(0, 0, leaderboard.totalWidth(), MainPanel.SCREEN_HEIGHT/2);
        

        label = new JLabel(new ImageIcon("images/StartScreen.png"));
        add(label);
        label.setBounds(0,0,MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);





    }

    



    @Override
    public void mouseClicked(java.awt.event.MouseEvent e)
    {
        int xcoord = e.getX();
        int ycoord = e.getY();
        //System.out.println("X:" + xcoord + "  Y:"+ ycoord);
        if(xcoord < 760)
        {
            return;
        }
        if(xcoord > 1160)
        {
            return;
        }
        if(ycoord < 400)
        {
            return;
        }
        if(ycoord > 550)
        {
            return;
        }
        main.setGamePanel();
    }
    @Override
    public void mousePressed(java.awt.event.MouseEvent e) {}
    @Override
    public void mouseReleased(java.awt.event.MouseEvent e) {}
    @Override
    public void mouseEntered(java.awt.event.MouseEvent e) {}
    @Override
    public void mouseExited(java.awt.event.MouseEvent e) {}}
