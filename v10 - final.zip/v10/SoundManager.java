import java.io.File;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class SoundManager
{

    public void play(String soundFileName)
	{
        try{
        Clip clip = AudioSystem.getClip();
        clip.open(AudioSystem.getAudioInputStream(new File("sounds/"+soundFileName+".wav")));
        clip.start();
        }catch(Exception ex){}
	}
    
}
