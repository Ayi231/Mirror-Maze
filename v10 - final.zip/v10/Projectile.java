import java.util.ArrayList;
import java.util.Random;

public class Projectile extends Sprite
{

    private final int projectileSpeed;
    private boolean right;
    private double downwardSpeed;

    private GamePanel game;
    private Sprite source;

    private Random rand;


    public Projectile(GamePanel game, int xPos, int yPos, boolean right, Sprite source)
    {
        super(game, "Projectile.png", false, 0, 0, 0, xPos, yPos);

        rand = new Random();
        projectileSpeed = 9+rand.nextInt(3);


        this.right = right;
        this.game = game;
        this.source = source;


    }

    public Projectile(GamePanel game, int xPos, int yPos, double downwardSpeed, Sprite source)
    {
        super(game, "Projectile.png", false, 0, 0, 0, xPos, yPos);
        
        rand = new Random();
        projectileSpeed = 10+rand.nextInt(5);

        this.downwardSpeed = downwardSpeed;

        right = false;
        this.game = game;
        this.source = source;


    }



    public void tick()
    {

        
        setXPos(getXPos()+(projectileSpeed*(right?1:-1)));
        setYPos(getYPos()+(int)(projectileSpeed*downwardSpeed));

        ArrayList<Sprite> c = game.getSpriteManager().checkCollisions(this);

        if(c.contains(game.getSpriteManager().getPlayer()) && source.toString() != "Player")
        {
            game.getSpriteManager().getPlayer().takeDamage();
            this.kill();
        }
        for (Sprite sprite : c)
        {
            if(sprite.toString() == "Enemy" && source.toString() != "Enemy")
            {
                sprite.kill();
                kill();
            }
            if(sprite.toString() == "Boss" && source.toString() != "Boss")
            {
                sprite.kill();
                kill();
            }
            
        }

        if(game.getWorld().checkCollisions(this).anyCollision())
        {
            kill();
        }


    }




    public String toString()
    {
        return "Projectile";
    }

    
}
