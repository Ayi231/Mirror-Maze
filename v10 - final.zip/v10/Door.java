import javax.swing.ImageIcon;

public class Door extends PermanentSprite
{

    private boolean[] doorsOpen = {false, false, true};
    private int activeDoor = 0;

    private ImageIcon openIcon, closedIcon, cageIcon, openCageIcon;


    private final int[][] overworldXPos = 
    {
        {MainPanel.SCREEN_WIDTH, 1680},//L1
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L2
        {1800, 1700}//L3
    };
    private final int[][] overworldYPos = 
    {
        {MainPanel.SCREEN_HEIGHT, 760},//L1
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L2
        {760, 760}//L3
    };
    private final int[][] mirrorXPos = 
    {
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L1
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH},//L2
        {MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_WIDTH}//L3
    };
    private final int[][] mirrorYPos = 
    {
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L1
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT},//L2
        {MainPanel.SCREEN_HEIGHT, MainPanel.SCREEN_HEIGHT}//L3
    };


    public Door(GamePanel game)
    {
        super(game, "door.png", false, 0, 0, 0, 0,0);


        openIcon = new ImageIcon("images/sprites/openDoor.png");
        closedIcon = new ImageIcon("images/sprites/door.png");
        cageIcon = new ImageIcon("images/sprites/cage.png");
        openCageIcon = new ImageIcon("images/sprites/openCage.png");
        
    }

    public void setStage(int level, int stage, boolean overworld)
    {
          
        if(level == 1 && stage == 2){activeDoor = 1;}
        else if(level == 3 && stage == 1){activeDoor = 2;}
        else if(level == 3 && stage == 2){activeDoor = 3;}
        else{activeDoor=0;}



        level--;
        stage--;
        //System.out.println(overworld);
        if(overworld)
        {
            setXPos(overworldXPos[level][stage]);
            setYPos(overworldYPos[level][stage]);
        }
        else //mirror world
        {
            setXPos(mirrorXPos[level][stage]);
            setYPos(mirrorYPos[level][stage]);
        }

        if(activeDoor > 0) 
            setIcon(doorsOpen[activeDoor-1]?openIcon:closedIcon); 
        
        if(activeDoor == 3)
            setIcon(doorsOpen[activeDoor-1]?openCageIcon:cageIcon);

    }


    public int getActiveDoor()
    {
        return activeDoor;
    }


    public Collision checkCollision(Sprite entity, Collision c)
    {   
        if(activeDoor == 0)
        {
            return c;
        }

        //System.out.println("ad:" + activeDoor  + "  open?:" + doorsOpen[activeDoor-1]);
        if(doorsOpen[activeDoor-1])
        {
            return c;
        }

        if(entity.getGroundCollision().intersects(super.getBodyCollision()))
            {
                c.ground = true;
            }

            if(entity.getBottomCollision().intersects(super.getBodyCollision()))
            {
                c.bottom = true;
                c.bottomSnap = getYPos()-entity.getHeight();
            }
        
            if(entity.getTopCollision().intersects(super.getBodyCollision()))
            {
                c.top = true;
                c.topSnap = getYPos()+getHeight();
            }
        
            if(entity.getLeftCollision().intersects(super.getBodyCollision()))
            {
                c.left = true;
                c.leftSnap = getXPos()+getWidth();
            }
        
            if(entity.getRightCollision().intersects(super.getBodyCollision()))
            {
                c.right = true;
                c.rightSnap = getXPos()-entity.getWidth();
            }



        return c;

    }

    public void open()
    {
        //System.out.println(activeDoor);
        if(activeDoor == 0)
            return;
        

        if(!doorsOpen[activeDoor-1])
            game.getSoundManager().play("button");
        doorsOpen[activeDoor-1] = true;
        setIcon(openIcon);

        if(activeDoor == 3)
        {
            game.getSpriteManager().getMirror().setXPos(40);
            game.getSpriteManager().getMirror().setYPos(760);
        }


    }

    public boolean getCageOpen()
    {
        return doorsOpen[2];
    }



    public String toString()
    {
        return "DOOR";
    }


    public void resetDoors()
    {
        for (int i = 0; i < doorsOpen.length; i++) {
            doorsOpen[i] = false;
        }


    }


}
