import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JPanel;

public class Stage extends JPanel
{

    
    //States of entire grid
    BlockTypes[][] worldBlocks = new BlockTypes[World.WORLD_HEIGHT][World.WORLD_WIDTH];

    //Tiles that need to be rendered (all not air)
    ArrayList<Tile> worldTiles = new ArrayList<Tile>();

    private int level, stage;
    private boolean overworld;

    public Stage(int level, int stage, boolean overworld)
    {
        this.level = level;
        this.stage = stage;
        this.overworld = overworld;
        setLayout(null);
        setOpaque(false);

        readWorldFile();
        

        //create arraylist of non air tiles
        for(int r = 0; r<worldBlocks.length; r++)
        {
            for(int c = 0; c<worldBlocks[0].length; c++)
            {
            
                if(worldBlocks[r][c] != BlockTypes.AIR)
                {
                    worldTiles.add(new Tile(worldBlocks[r][c], r, c, level));
                }
            }
        }
        //put tiles on panel
        for (Tile t: worldTiles)
        {
           add(t.getLabel()); 
        }




    }

    @Override
    protected void paintComponent(Graphics g) {
        // TODO Auto-generated method stub
        super.paintComponent(g);
        /*
        g.setColor(Color.GREEN);
        for (Tile t : worldTiles) {
            Rectangle r = t.getRectangle();
            g.drawRect((int)r.getX(), (int)r.getY(), (int)r.getWidth(), (int)r.getHeight());
            
        }//*/

    }



    public ArrayList<Tile> getWorldTiles()
    {
        return worldTiles;
    }


    private void readWorldFile()
    {

        try{
            //@SuppressWarnings("resource");
            //System.out.println("levels/" + (overworld?"O":"M") + "-" + level + "-" + stage + ".txt");
            BufferedReader reader = new BufferedReader(new FileReader("levels/" + (overworld?"O":"M") + "-" + level + "-" + stage + ".txt"));

            for(int r = 0; r<World.WORLD_HEIGHT; r++)
            {
                String line = reader.readLine();
                //System.out.println(line);
                for (int c = 0; c < World.WORLD_WIDTH; c++)
                {
                    char id = line.charAt(c);
                    switch(id)
                    {

                        case 'A':
                            worldBlocks[r][c] = BlockTypes.AIR;
                            break;

                        case 'W':
                            worldBlocks[r][c] = BlockTypes.WALL;
                            break;
                            
                        case 'B':
                            worldBlocks[r][c] = BlockTypes.BUTTON_LEFT;
                            break;

                        case 'b':
                            worldBlocks[r][c] = BlockTypes.BUTTON_RIGHT;
                            break;
                            
                        case 'C':
                            worldBlocks[r][c] = BlockTypes.CAGE;
                            break;



                        default:
                            worldBlocks[r][c] = BlockTypes.AIR;
                            break;

                    }
                }
            }


            reader.close();

        }catch(IOException e) {}


    }

}