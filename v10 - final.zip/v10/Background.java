import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class Background extends JPanel
{
    private GamePanel game;

    private ImageIcon level1, level2, level3;
    private JLabel backgroundLabel;


    public Background(GamePanel game)
    {
        this.game = game;



        level1 = new ImageIcon("images/background1.png");
        level2 = new ImageIcon("images/background2.png");
        level3 = new ImageIcon("images/background3.png");
        

        backgroundLabel = new JLabel(level1);
        
        backgroundLabel.setBounds(0,0,1920, 1080);
        add(backgroundLabel);
        
    }

    public void setLevel(int level)
    {
        switch (level) {
            case 1:
                backgroundLabel.setIcon(level1);
                break;
                
            case 2:
                backgroundLabel.setIcon(level2); 
                break;
                
            case 3:
                backgroundLabel.setIcon(level3); 
                break;
        }



    }

}
