import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.w3c.dom.css.Rect;

public class SpriteManager extends JPanel
{
    private GamePanel game;

    private EnemyList[][][] enemyLists = new EnemyList[2][3][2];

    private ArrayList<Sprite> stageSprites = new ArrayList<Sprite>();

    private ArrayList<PermanentSprite> permSprites = new ArrayList<PermanentSprite>();

    private Player p;
    private Door d;
    private Mirror m;
    private Button b;
    private Goal g;


    public SpriteManager(GamePanel game)
    {
        this.game = game;
        setLayout(null);

        setOpaque(false);

        setupEnemies();
        
        
        p = new Player(game);
        permSprites.add(p);
        
        d = new Door(game);
        permSprites.add(d);
        
        m = new Mirror(game);
        permSprites.add(m);
        
        b = new Button(game);
        permSprites.add(b);

        g = new Goal(game);
        permSprites.add(g);
        

        for (Sprite sprite : permSprites) {
            add(sprite);
        }


        
        
    }


    public void spawnProjectile(int x, int y, boolean right, Sprite source)
    {
        Projectile projectile = new Projectile(game, x, y, right, source);
        stageSprites.add(projectile);
        add(projectile);
        repaint();



    }
    
    public void spawnProjectile(int x, int y, double downwardSpeed, Sprite source)
    {
        Projectile projectile = new Projectile(game, x, y, downwardSpeed, source);
        stageSprites.add(projectile);
        add(projectile);
        repaint();



    }



    @Override
    protected void paintComponent(Graphics g) {
        // TODO Auto-generated method stub
        super.paintComponent(g);
        /*

        g.setColor(Color.RED);
        g.fillRect((int)p.getBottomCollision().getX(), (int)p.getBottomCollision().getY(), (int)p.getBottomCollision().getWidth(), (int)p.getBottomCollision().getHeight());
        g.fillRect((int)p.getTopCollision().getX(), (int)p.getTopCollision().getY(), (int)p.getTopCollision().getWidth(), (int)p.getTopCollision().getHeight());
        g.fillRect((int)p.getLeftCollision().getX(), (int)p.getLeftCollision().getY(), (int)p.getLeftCollision().getWidth(), (int)p.getLeftCollision().getHeight());
        g.fillRect((int)p.getRightCollision().getX(), (int)p.getRightCollision().getY(), (int)p.getRightCollision().getWidth(), (int)p.getRightCollision().getHeight());
        g.setColor(Color.MAGENTA);
        g.fillRect((int)p.getGroundCollision().getX(), (int)p.getGroundCollision().getY(), (int)p.getGroundCollision().getWidth(), (int)p.getGroundCollision().getHeight());
        repaint();
        //*/

    }


    public ArrayList<Sprite> checkCollisions(Sprite entity)
    {
        ArrayList<Sprite> c = new ArrayList<Sprite>();

        for (Sprite sprite : permSprites)
        {
            if(sprite == entity)
                continue;

            if(sprite.getBodyCollision().intersects(entity.getBodyCollision()) && !c.contains(sprite))
                c.add(sprite);

        }
        for (Sprite sprite : stageSprites)
        {
            if(sprite == entity)
                continue;

            if(sprite.getBodyCollision().intersects(entity.getBodyCollision()) && !c.contains(sprite))
            c.add(sprite);

        }




        return c;

    }


    public void tick()
    {
        for (Sprite s : permSprites) 
        {
            s.tick();
        }
        for (int i = 0; i< stageSprites.size(); i++) 
        {
            Sprite s = stageSprites.get(i);
            s.tick();

            if(!s.isAlive())
            {
                stageSprites.remove(s);
                remove(s);
                game.repaint();
            }
        }
    }


    public void setStage(int level, int stage, boolean overworld)
    {

        for (PermanentSprite ps : permSprites)
        {
            ps.setStage(level, stage, overworld);
        }
        for (Sprite sprite : stageSprites)
        {
            remove(sprite);   
        }
        stageSprites = enemyLists[overworld?0:1][level-1][stage-1].enemies;
        for (Sprite sprite : stageSprites)
        {
            add(sprite);    
        }

    }



    public void setupEnemies()
    {

        for (int dim = 0; dim < enemyLists.length; dim++) {
                for (int lev = 0; lev < enemyLists[0].length; lev++) {
                    for (int stg = 0; stg < enemyLists[0][0].length; stg++) {
                        enemyLists[dim][lev][stg] = new EnemyList(dim, lev, stg, game);
                    }
                    
                }
        }

    }


    public Door getDoor(){return d;}
    public Button getButton(){return b;}
    public Player getPlayer(){return p;}
    public Mirror getMirror(){return m;}
    public ArrayList<Sprite> getStageSprites(){return stageSprites;}


}
