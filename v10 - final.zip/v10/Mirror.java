public class Mirror extends PermanentSprite
{

    private final int[][] overworldXPos = 
    {
        {1800, 0},//L1
        {1440, 0},//L2
        {0, 1800}//L3
    };
    private final int[][] overworldYPos = 
    {
        {760 , 320},//L1
        {0, 0},//L2
        {0, 80}//L3
    };      
    private final int[][] mirrorXPos = 
    {
        {40, 1800},//L1
        {40, 1760},//L2
        {40, MainPanel.SCREEN_WIDTH}//L3
    };
    private final int[][] mirrorYPos = 
    {
        {760, 240},//L1
        {760, 760},//L2
        {0, MainPanel.SCREEN_HEIGHT}//L3
    };



    public Mirror(GamePanel game)
    {   
        super(game, "mirror.png", false, 0, 0, 0, 0, 0);


    }

    public void setStage(int level, int stage, boolean overworld)
    {
        level--;
        stage--;
        if(overworld)
        {
            setXPos(overworldXPos[level][stage]);
            setYPos(overworldYPos[level][stage]);
        }
        else //mirror world
        {
            setXPos(mirrorXPos[level][stage]);
            setYPos(mirrorYPos[level][stage]);
        }


        
        
    }

    public String toString()
    {
        return "Mirror";
    }

}
