public class Placement implements Comparable<Placement>
{
    private String name;
    private String time;
    private long millis;

    public Placement(String name, String time, long millis)
    {
        this.name = name;
        this.time = time;
        this.millis = millis;
    }

    public String getName()
    {
        return name;
    }
    public String getTime()
    {
        return time;
    }
    public long getMillis()
    {
        return millis;
    }

    @Override
    public int compareTo(Placement o) {
        return (int)(millis - o.millis);
    }
    

    public String toString()
    {
        return name + "| " + time;
    }


}
