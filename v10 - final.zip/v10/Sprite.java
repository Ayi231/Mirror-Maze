import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public abstract class Sprite extends JLabel
{
    protected ImageIcon image;

    //physics parameters
    private final double g = 0.5;//1.0;
    private boolean gravityActive;

    
    //movement parameters
    private int maxMovementSpeed;
    private double accelerationRate, decelerationRate;
    

    //entity data
    private int xPos, yPos;
    protected double xVelo = 0, yVelo = 0;
    protected boolean onGround = false;
    private boolean alive = true;

    //control
    protected int moveDirection = 0;

    //collision
    private Rectangle bottomCollision, topCollision, leftCollision, rightCollision, groundCollision, bodyCollision;

    //access to other panels
    protected GamePanel game;

    public Sprite(GamePanel game, String imageName, boolean gravityActive, int maxSpeed, double acceleration, double deceleration, int xPos, int yPos)
    {
        this.game = game;
        image = new ImageIcon("images/sprites/"+imageName);
        setIcon(image);
        this.gravityActive = gravityActive;
        this.maxMovementSpeed = maxSpeed;
        this.accelerationRate = acceleration;
        this.decelerationRate = deceleration;
        this.xPos = xPos;
        this.yPos = yPos;

        bottomCollision = new Rectangle();
        topCollision = new Rectangle();
        leftCollision = new Rectangle();
        rightCollision = new Rectangle();
        groundCollision = new Rectangle();
        bodyCollision = new Rectangle();

        
        updateBounds();


    }
    

    public void setXPos(int x)
    {
        xPos = x;
        updateBounds();
    }
    public int getXPos()
    {
        return xPos;
    }
    public void setYPos(int y)
    {
        yPos = y;
        updateBounds();
    }
    public int getYPos()
    {
        return yPos;
    }

    public void kill()
    {
        alive = false;
    }
    public boolean isAlive()
    {
        return alive;
    }
    
    /*
     * try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e){}
     */
    
    public void tick()
    {
        if(!gravityActive)
        {
            return;
        }
        
        int oldX = xPos;
        int oldY = yPos;
        
        
        //update pos by velocity
        xPos+=xVelo;
        yPos+=yVelo;

        
        //only gravity if not on ground
        if(!onGround)
        {
            //y acceleration = gravity (g)
            yVelo+=g;

        }
        


        //x acceleration based on controls
        switch (moveDirection) {
            case 1://right / positive
                xVelo+=accelerationRate;
                break;
            
            case -1://left / negative
                xVelo-=accelerationRate;
                break;
            
            case 0://no input / slow down

                if(xVelo > 0)//moving right
                    xVelo-=decelerationRate;
                else if(xVelo < 0)//moving left
                    xVelo+=decelerationRate;

                break;
            
                
            default:
                System.err.println("unknown move direction");
                break;
        }


        //constrain if goes above max speed
        if(xVelo > maxMovementSpeed)
            xVelo=maxMovementSpeed;
        else if(xVelo < -maxMovementSpeed)
            xVelo = -maxMovementSpeed;





        updateCollisionBounds();


        Collision collisions = game.getWorld().checkCollisions(this);

        //onGround = collisions.ground;
        if(!collisions.ground && yVelo >= 0)
            onGround = false;


        if(collisions.left && !collisions.right)
        {
            xPos = collisions.leftSnap;
            xVelo = 0;
            //moveDirection = 0;
        }
        if(collisions.right && !collisions.left)
        {
            
            xPos = collisions.rightSnap;
            xVelo = 0;  
            //moveDirection = 0;
        }
        if(collisions.top)
        {
            yPos = collisions.topSnap;
            if(yVelo < 0)
                yVelo = 0;
        }
        if(collisions.bottom && !(collisions.right || collisions.left))
        {
            yPos = collisions.bottomSnap;
            //System.out.println(yVelo);
            if(yVelo>20 && toString()=="Player")
            {
                game.getSpriteManager().getPlayer().takeDamage();
            }
            yVelo = 0;
            onGround = true;
            //System.out.println("Hit ground");
            //System.out.println(yVelo);
        }

        updateBounds();

       
    }


    private void updateBounds()
    {
        updateVisualBounds();
        updateCollisionBounds();
    }
    private void updateCollisionBounds()
    {
        leftCollision.setBounds(xPos, yPos+image.getIconHeight()/4, 1, 3*image.getIconHeight()/8);
        rightCollision.setBounds(xPos+image.getIconWidth()-1, yPos+image.getIconHeight()/4, 1, 3*image.getIconHeight()/8);
        topCollision.setBounds(xPos+3*image.getIconWidth()/8, yPos, image.getIconWidth()/4, 1);
        bottomCollision.setBounds(xPos+image.getIconWidth()/3, yPos+image.getIconHeight()-1, image.getIconWidth()/3, 1);
        int overhang = 10;
        groundCollision.setBounds(xPos-overhang, yPos+image.getIconHeight(), image.getIconWidth()+(2*overhang), 1);
    }
    private void updateVisualBounds()
    {
        setBounds(xPos, yPos, image.getIconWidth(), image.getIconHeight());
        bodyCollision.setBounds(xPos, yPos, image.getIconWidth(), image.getIconHeight());
    }


    public Rectangle getTopCollision(){return topCollision;}
    public Rectangle getBottomCollision(){return bottomCollision;}
    public Rectangle getLeftCollision(){return leftCollision;}
    public Rectangle getRightCollision(){return rightCollision;}
    public Rectangle getGroundCollision(){return groundCollision;}
    public Rectangle getBodyCollision(){return bodyCollision;}



    public String toString()
    {
        return "Generic Sprite";
    }


}
