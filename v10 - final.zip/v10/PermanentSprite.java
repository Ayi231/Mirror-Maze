public abstract class PermanentSprite extends Sprite
{
    
    public PermanentSprite(GamePanel game, String imageName, boolean gravityActive, int maxSpeed, double acceleration, double deceleration, int xPos, int yPos)
    {
        super(game, imageName, gravityActive, maxSpeed, acceleration, deceleration, xPos, yPos);
    }


    public abstract void setStage(int level, int stage, boolean overworld);


}
