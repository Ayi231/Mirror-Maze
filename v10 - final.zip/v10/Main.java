import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;

class Main
{

    public static void main(String[] args)
    {
        JFrame frame = new JFrame();
        MainPanel panel = new MainPanel();
       
		//frame setup
		frame.setContentPane(panel);
		frame.setUndecorated(true);
		frame.setResizable(false);
		frame.setVisible(true);
		try{frame.setIconImage(ImageIO.read(new File("images/logo.png")));}catch (IOException e) {}
		
		//frame windowed
		frame.setSize(1920, 1080);

		//primary monitor fullscreen
		//GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(frame);
		
		//2nd monitor fullscreen
		//GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices()[1].setFullScreenWindow(frame);

    }

}