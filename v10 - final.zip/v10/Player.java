import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Player extends PermanentSprite implements KeyListener
{
    
    private final int[][] overworldXPos = 
    {
        {150,160},//L1
        {50,150},//L2
        {150,60}//L3
    };
    private final int[][] overworldYPos = 
    {
        {890,450},//L1
        {890,130},//L2
        {890,890}//L3
    };
    private final int[][] mirrorXPos = 
    {
        {250,80},//L1
        {200,80},//L2
        {240,140}//L3
    };
    private final int[][] mirrorYPos = 
    {
        {770,370},//L1
        {890,570},//L2
        {130,890}//L3
    };

    GamePanel game;

    private boolean leftPressed = false, rightPressed = false;
    private final char UP = 'w', LEFT = 'a', RIGHT = 'd', UP_CAPS = 'W', LEFT_CAPS = 'A', RIGHT_CAPS = 'D';
    private boolean facingRight = true;

    private boolean toNextAvailable = false;

    private ImageIcon right, left;

    private final int MAX_HEALTH = 3;
    private int health;

    public static final int ATTACK_COOLDOWN = 15;
    private int attackTimer;

    public static final int MAX_AMMO = 3;
    private int ammo = MAX_AMMO, ammoRefillTimer = 0;


    private long lastInput;

    public Player(GamePanel game)
    {
        super(game, "BOY_R.png", true, 15, 6, 1, 1000, 200);
        this.game = game;

        lastInput = System.currentTimeMillis();

        right = super.image;
        left = new ImageIcon("images/sprites/BOY_L.png");

        game.addKeyListener(this);
        


    }


    public void setStage(int level, int stage, boolean overworld)
    {
        lastInput = System.currentTimeMillis();
        level--;
        stage--;
        if(overworld)
        {
            setXPos(overworldXPos[level][stage]);
            setYPos(overworldYPos[level][stage]);
        }
        else //mirror world
        {
            setXPos(mirrorXPos[level][stage]);
            setYPos(mirrorYPos[level][stage]);
        }
    }


    public void tick()
    {
        //System.out.println("Time since last input: " + (System.currentTimeMillis()-lastInput));
        if(System.currentTimeMillis()-lastInput > 20000)
        {
            game.getMainPanel().setMenuPanel();
        }
        super.tick();
        if(attackTimer > 0)
        {
            attackTimer--;
            game.getHUD().setCooldown(attackTimer);
        }
        ArrayList<Sprite> c = game.getSpriteManager().checkCollisions(this);
        for (Sprite sprite : c) {
            //System.out.println(sprite);
            switch (sprite.toString()) {
                case "Button":
                    game.getSpriteManager().getDoor().open();
                    break;

                case "Target":
                    if(game.getSpriteManager().getDoor().getCageOpen())
                        game.win();
                    break;

                case "Boss":
                    takeDamage();
                    break;

            }

        }


        boolean offScreenRight = super.getXPos() > (MainPanel.SCREEN_WIDTH);
        boolean offScreenLeft = super.getXPos() < -10;
        boolean inMirror = c.contains(game.getSpriteManager().getMirror());

        if(offScreenRight && toNextAvailable)
        {
            game.nextStage();
            //System.out.println("NEXT");
            toNextAvailable = false;
        }
        else if(offScreenLeft && toNextAvailable)
        {
            game.prevStage();
            toNextAvailable = false;
        }
        else if(inMirror && toNextAvailable)
        {
            game.throughMirror();
            //tSystem.out.println("MIRRORRR");
            toNextAvailable = false;
        }
        else if(!offScreenRight && !inMirror && !toNextAvailable)
        {
            //System.out.println("reset");
            toNextAvailable = true;
        }


        if(ammo<MAX_AMMO)
        {
            ammoRefillTimer++;
        }
        if(ammoRefillTimer>=70)
        {
            ammoRefillTimer = 0;
            ammo++;
            game.getHUD().setAmmo(ammo);
        }




    }

    


    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub
        //System.out.println("TYPE");
        lastInput = System.currentTimeMillis();
        switch (e.getKeyChar()) {
            case UP:
            case UP_CAPS:
                if(onGround)
                {
                    yVelo = -10.7;//-12;
                    onGround = false;
                    game.getSoundManager().play("jump");
                }
                break;
                
            
            /*case 'z':
            case 'x':
            case 'c':
            case 'v':
            case 'b':
            case 'n':*/
            case ' ':
                attack();
                break;

            case 'R':
                game.getMainPanel().setMenuPanel();
                break;
                
            /*
            case 'c':
                //game.getWorld().nextStage();
                //game.getSpriteManager().d.openDoor();
                //System.out.println("X: " + getXPos() + "    Y: " + getYPos());
                break;
            case 'H':
                fullHealth();
                break;
            case 'K':
                takeDamage();
                takeDamage();
                takeDamage();
                break;
            case 'T':
                //System.out.println(game.getMousePosition());
                setXPos(game.getMousePosition().x);
                setYPos(game.getMousePosition().y);
                break;
            case 'R':
                attackTimer = 0;
                game.getHUD().setCooldown(attackTimer);
                break;*/
        }

        
    }


    private void attack()
    {
        if(ammo <= 0 )
            return;
        if(attackTimer > 0)
            return;
        
        game.getSpriteManager().spawnProjectile(getXPos()+(facingRight?this.getWidth():-30), getYPos(), facingRight, this);
        attackTimer = ATTACK_COOLDOWN;
        ammo--;
        game.getHUD().setAmmo(ammo);
        game.getHUD().setCooldown(attackTimer);
        game.getSoundManager().play("shoot");
        
        }
        
        
    public void reset()
    {
        xVelo = 0;
        yVelo = 0;
        moveDirection = 0;
        attackTimer = 0;
        ammo = MAX_AMMO;
        game.getHUD().setCooldown(attackTimer);
        game.getHUD().setAmmo(ammo);
    }


    public void fullHealth()
    {
        health = MAX_HEALTH;
        game.getHUD().setHealthDisplay(health);
    }
    public void takeDamage()
    {
        health--;
        game.getSoundManager().play("damage");
        game.getHUD().setHealthDisplay(health);
        if(health == 0)
        {
            game.death();
        }
    }


    @Override
    public void keyPressed(KeyEvent e) {
        lastInput = System.currentTimeMillis();   
        updateKeys(e, true);
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        lastInput = System.currentTimeMillis();   
        updateKeys(e, false);
    }

    private void updateKeys(KeyEvent e, boolean pressed)
    {
        switch(e.getKeyChar())
        {
            case LEFT:
            case LEFT_CAPS:
                leftPressed = pressed;
                if(pressed)
                {
                    facingRight = false;
                    setIcon(left);
                }
                break;
                
            case RIGHT:
            case RIGHT_CAPS:
                rightPressed = pressed;
                if(pressed)
                {
                    facingRight = true;
                    setIcon(right);
                }
                break;
            
            default:
                break;


        }


        moveDirection = (rightPressed?1:0) - (leftPressed?1:0);

        

        //System.out.println(moveDirection);


    }


    public String toString()
    {
        return "Player";
    }

}
