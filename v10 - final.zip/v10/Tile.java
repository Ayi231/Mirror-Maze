import java.awt.Rectangle;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Tile
{
    public static final int SIZE = 40;

    private BlockTypes type;

    private Rectangle collisionBox;
    
    private ImageIcon image;
    private JLabel label;

    private int row, col;



    public Tile(BlockTypes type, int row, int col, int level)
    {
        this.type = type;
        this.row = row;
        this.col = col;


        collisionBox = new Rectangle();
        collisionBox.setBounds(col*SIZE, row*SIZE, SIZE, SIZE);

        
        switch (type)
        {

            case WALL:
                image = new ImageIcon("images/tiles/"+level+"brick.png");
                break;

            case CAGE:
                image = new ImageIcon("images/tiles/"+level+"cage.png");
                break;
        
            default:
                break;
        }

        label = new JLabel(image);
        label.setBounds(collisionBox);


    }


    




    public JLabel getLabel(){return label;}
    public Rectangle getRectangle(){return collisionBox;}


    public int getRow(){return row;}
    public int getCol(){return col;}



}
