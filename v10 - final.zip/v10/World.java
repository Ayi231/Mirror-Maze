import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JPanel;

public class World extends JPanel
{
    //access to other classes
    GamePanel game;

    //World Grid Size
    final static int WORLD_HEIGHT = MainPanel.SCREEN_HEIGHT/Tile.SIZE, WORLD_WIDTH = MainPanel.SCREEN_WIDTH/Tile.SIZE;

    private Stage activeStage;


    public World(GamePanel game)
    {
        this.game = game;

        //panel setup
        setOpaque(false);
        setLayout(null);

        setStage(1, 1, true);

    }
    
    
    
    public Collision checkCollisions(Sprite entity)
    {
        
        Collision c = new Collision();

        for (Tile t : activeStage.getWorldTiles())
        {
            Rectangle r = t.getRectangle();

            if(entity.getGroundCollision().intersects(r))
            {
                c.ground = true;
            }

            if(entity.getBottomCollision().intersects(r))
            {
                c.bottom = true;
                c.bottomSnap = t.getRow()*Tile.SIZE-entity.getHeight();
            }
        
            if(entity.getTopCollision().intersects(r))
            {
                c.top = true;
                c.topSnap = (t.getRow()+1)*Tile.SIZE;
            }
        
            if(entity.getLeftCollision().intersects(r))
            {
                c.left = true;
                c.leftSnap = (t.getCol()+1)*Tile.SIZE;
            }
        
            if(entity.getRightCollision().intersects(r))
            {
                c.right = true;
                c.rightSnap = t.getCol()*Tile.SIZE-entity.getWidth();
            }

               
        }



        c = game.getSpriteManager().getDoor().checkCollision(entity, c);





        return c;
    }



    
    public void setStage(int level, int stage, boolean overworld)
    {
        if(activeStage != null)
            remove(activeStage);
        activeStage = new Stage(level, stage, overworld);
        add(activeStage);
        activeStage.setBounds(0, 0, MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        game.getHUD().setDisplayLevel(level, stage, overworld);
        game.getHUD().setBossHealthVisible(level == 3 && stage == 2 && !overworld);
    }
    


}
