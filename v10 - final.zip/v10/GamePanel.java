import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener
{
    private MainPanel main;
    private Leaderboard leaderboard;
    private SoundManager soundManager;

    private HUD hud;
    private SpriteManager spriteManager;
    private World world;
    private Background gameBackground;

    private JLayeredPane layers;

    private Timer clock, deathReset;

    private int level, stage;
    private boolean inOverworld = true;

    private long startMillis;


    public GamePanel(MainPanel main, Leaderboard leaderboard)
    {
        this.main = main;
        this.leaderboard = leaderboard;

        soundManager = new SoundManager();

        clock = new Timer(20, this);
        deathReset = new Timer(2500, this);

        //layout null
        setLayout(null);
        
        //instantiate layered pane
        layers = new JLayeredPane();
        
        //instantiate sub panels
        hud = new HUD(this);
        spriteManager = new SpriteManager(this);
        world = new World(this);
        gameBackground = new Background(this);

        
        this.setFocusable(true);
        hud.setFocusable(false);
        spriteManager.setFocusable(false);
        world.setFocusable(false);
        gameBackground.setFocusable(false);

        
        

        //test stuff
        /*setBackground(Color.magenta);
        JButton button = new JButton();
        add(button);
        button.addActionListener(this);*/


        add(layers);
        layers.setBounds(0, 0, MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);




        layers.add(gameBackground);
        gameBackground.setBounds(0, 0, MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        layers.moveToFront(gameBackground);
        
        layers.add(world);
        world.setBounds(0,0,MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        layers.moveToFront(world);
        
        layers.add(spriteManager);
        spriteManager.setBounds(0,0,MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        layers.moveToFront(spriteManager);
        
        layers.add(hud);
        hud.setBounds(0,0,MainPanel.SCREEN_WIDTH, MainPanel.SCREEN_HEIGHT);
        layers.moveToFront(hud);




    }


    public void startGame()
    {
        spriteManager.getPlayer().fullHealth();
        level = 1;
        stage = 1;
        inOverworld = true;
        spriteManager.setStage(level, stage, inOverworld);
        world.setStage(level, stage, inOverworld);
        spriteManager.getPlayer().reset();
        gameBackground.setLevel(level);
        startMillis = System.currentTimeMillis();
        spriteManager.setupEnemies();
        spriteManager.getDoor().resetDoors();

    }




    public void throughMirror()
    {
        inOverworld = !inOverworld;

        world.setStage(level, stage, inOverworld);
        spriteManager.setStage(level, stage, inOverworld);

        spriteManager.getPlayer().xVelo = 0;


    }


    public void win()
    {

        stopGameClock();
        hud.promptNameInput();

    }

    public void death()
    {
        stopGameClock();
        hud.deathMsg(true);
        deathReset.start();
        soundManager.play("lose");
    }


    public void nextStage()
    {
        
        if(stage == 1)
        {   //next stage
            stage++;

        }
        else if(stage > 1)
        {   //next level
            stage = 1;
            level++;

        }
        //System.out.println(level + "_" + stage);

        world.setStage(level, stage, inOverworld);
        spriteManager.setStage(level, stage, inOverworld);
        gameBackground.setLevel(level);

        
        
        
    }
    public void prevStage()
    {
        
        if(stage == 1)
        {   //next stage
            stage++;
            level--;
            
        }
        else if(stage > 1)
        {   //next level
            stage--;

        }
        //System.out.println(level + "_" + stage);
        
        world.setStage(level, stage, inOverworld);
        spriteManager.setStage(level, stage, inOverworld);
        gameBackground.setLevel(level);
        
        
        
        
        
    }
    
    
    
    
    
    
















    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == clock)
        {
            spriteManager.tick();
            hud.setStopwatch(System.currentTimeMillis()-startMillis);
        }
        else if(e.getSource() == deathReset)
        {
            deathReset.stop();
            main.setMenuPanel();
            hud.deathMsg(false);
        }
    }


    public void startGameClock()
    {
        clock.start();
    }
    public void stopGameClock()
    {
        clock.stop();
    }
    

    public HUD getHUD(){return hud;}
    public SpriteManager getSpriteManager(){return spriteManager;}
    public World getWorld(){return world;}
    public Background getGameBackground(){return gameBackground;}
    public MainPanel getMainPanel(){return main;}
    public SoundManager getSoundManager(){return soundManager;}

}
