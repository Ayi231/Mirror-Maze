import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Leaderboard extends JPanel
{
    private final String FILE_SEPARATOR = "ae5341be-d2d3-4860-b2bb-b67a6edaf72b";

    private JLabel[][] labels = new JLabel[11][3];
    private JPanel places, names, times;

    private ArrayList<Placement> placements = new ArrayList<Placement>();

    private final int pWidth = 50, nWidth = 200, tWidth = 150;

    private Font font = new Font(Font.MONOSPACED, Font.BOLD, 20);
    
    public Leaderboard()
    {

        setLayout(null);
        setOpaque(false);

        places = new JPanel(new GridLayout(11, 1));
        add(places);
        places.setBounds(0,0,pWidth,MainPanel.SCREEN_HEIGHT/2);
        places.setOpaque(false);

        names = new JPanel(new GridLayout(11, 1));
        add(names);
        names.setBounds(pWidth,0,nWidth,MainPanel.SCREEN_HEIGHT/2);
        names.setOpaque(false);
        
        times = new JPanel(new GridLayout(11, 1));
        add(times);
        times.setBounds(pWidth+nWidth,0,tWidth,MainPanel.SCREEN_HEIGHT/2);
        times.setOpaque(false);


        labels[0][0] = new JLabel();
        labels[0][1] = new JLabel("Name");
        labels[0][2] = new JLabel("Time");


        for (int row = 1; row < labels.length; row++)
        {
            labels[row][0] = new JLabel(row+"");
            
            labels[row][1] = new JLabel("__________");
            
            labels[row][2] = new JLabel("00:00.0000");
        }
        

        for (int row = 0; row < labels.length; row++)
        {
            
            places.add(labels[row][0]);
            names.add(labels[row][1]);
            times.add(labels[row][2]);

            for (int col = 0; col < labels[0].length; col++)
            {
                labels[row][col].setHorizontalAlignment(SwingConstants.CENTER);
                labels[row][col].setFont(font);
                labels[row][col].setForeground(Color.WHITE);
                
            }
            
        }


        readFile();


    }

    public int totalWidth()
    {
        return pWidth+nWidth+tWidth;
    }

    public Font getFont()
    {
        return font;
    }

    
    public void addPlacement(Placement p)
    {
        //System.out.println(p);
        placements.add(p);
        updatePlacements();
        writeFile();
    }


    private void updatePlacements()
    {
        Collections.sort(placements);

        //System.out.println(placements);

        for (int i = 0; i < 10 && i < placements.size(); i++)
        {
            labels[i+1][1].setText(placements.get(i).getName());
            labels[i+1][2].setText(placements.get(i).getTime());
        }


    }







    private void writeFile()
    {

        try{

            BufferedWriter bf = new BufferedWriter(new FileWriter("leaderboard.txt"));

            for (Placement p : placements)
            {

                bf.write(p.getName() + FILE_SEPARATOR + p.getTime() + FILE_SEPARATOR + p.getMillis() + "\n");



            }

            bf.close();


        }catch(IOException ex){}




    }

    private void readFile()
    {

        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader("leaderboard.txt"));

            String line = reader.readLine();

            while (line != null)
            {
                //System.out.println(line);

                String[] data = line.split(FILE_SEPARATOR);
                if(data.length < 3)
                    continue;

                placements.add(new Placement(data[0], data[1], Long.parseLong(data[2])));

                
                line = reader.readLine();
            }



            reader.close();

            updatePlacements();


        } catch (FileNotFoundException e) {} catch (IOException e) {}



    }
    
}
