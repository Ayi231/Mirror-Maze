public class Collision
{
    
    public boolean left, right, top, bottom, ground;
    public int leftSnap, rightSnap, topSnap, bottomSnap;

    public boolean anyCollision()
    {
        return left||right||top||bottom;
    }
    
}
