import java.util.ArrayList;

public class EnemyList
{

    public ArrayList<Sprite> enemies = new ArrayList<Sprite>();


    public EnemyList(int dimension, int level, int stage, GamePanel game)
    {

        switch (dimension)
        {
            case 0://O
                switch (level)
                {
                    case 0://O-1
                        switch (stage)
                        {
                            case 0://O-1-1
                                //enemies.add(new Enemy(game, 1000, 200));
                                break;
                            case 1://O-1-2

                                break;
                        }
                        break;
                    case 1://O-2
                        switch (stage)
                        {
                            case 0://O-2-1
                                enemies.add(new Enemy(game, 1800, 530, 2, -2));
                                
                                break;
                            case 1://O-2-2

                                break;
                        }
                        break;
                    case 2://O-3
                        switch (stage)
                        {
                            case 0://O-3-1
                                enemies.add(new Enemy(game, 380, 130, 3, 5));
                                enemies.add(new Enemy(game, 710, 130, 2, 2));
                                enemies.add(new Enemy(game, 575, 410, 2, 3));
                                break;
                            case 1://O-3-2

                                break;
                        }
                        break;
                }
                break;
        
            case 1://M
                switch (level)
                {
                    case 0://M-1
                        switch (stage)
                        {
                            case 0://M-1-1
                                
                                break;
                            case 1://M-1-2
                                enemies.add(new Enemy(game, 800, 400, 5, 7));
                                break;
                        }
                        break;
                        
                    case 1://M-2
                        switch (stage)
                        {
                            case 0://M-2-1
                                enemies.add(new Enemy(game, 1000, 530, 0, 5));
                                enemies.add(new Enemy(game, 1200, 530, 1, 5));
                                enemies.add(new Enemy(game, 1400, 530, 10, 10));
                                enemies.add(new Enemy(game, 1600, 530, 5, 1));
                                enemies.add(new Enemy(game, 1800, 530, 5, 1));
                                break;
                            case 1://M-2-2
                                enemies.add(new Enemy(game, 400, 530, 2, 5));
                                enemies.add(new Enemy(game, 600, 530, 1, 5));
                                enemies.add(new Enemy(game, 800, 530, 8, 10));
                                enemies.add(new Enemy(game, 1000, 530, 5, 1));
                                enemies.add(new Enemy(game, 1200, 530, 5, 0));
                                
                                break;
                        }
                        break;
 
                    case 2://M-3
                        switch (stage)
                        {
                            case 0://M-3-1
                                
                                break;
                            case 1://M-3-2
                                enemies.add(new Enemy(game, 960, 340));
                                break;
                        }
                        break;
                }
                break;
        }



















    }

    
    
}
